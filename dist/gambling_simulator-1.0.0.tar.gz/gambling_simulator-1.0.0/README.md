# Gambling Simulator

Gambling Simulator is a fast-paced command-line game all about taking risks.
Start with a small fortune and try your luck — just don’t lose it all!

**Documentation:** [Documentation](https://github.com/Ivole32/gambling-simulator/wiki)

AI Disclaimer:
I user AI to build some parts of the program / to correct parts of the *.md files
